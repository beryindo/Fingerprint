This is an Arduino library for the FPM10/R305/ZFM20 fingerprint sensor.
Also included is a Python script and an executable for extracting fingerprint images to a PC; the 'finger2PC' example must first be uploaded to the Arduino.

Datasheet found at https://sicherheitskritisch.de/files/specifications-2.0-en.pdf